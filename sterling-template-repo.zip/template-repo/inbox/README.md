# inbox/ — Drop Zone for User-Provided Research

This folder is where the person you're working with drops files they want Sterling to read: news articles, PDFs, research reports, spreadsheets, or premium/paywalled content (e.g. WSJ, Barron's, broker notes) that isn't reachable on the open web.

Anything placed here should be treated as material they've personally flagged as worth attention — read it and factor it into analysis, citing it as a user-provided source (not a web source) in calls and in the decision log.

See MONITORING.md (daily cycle) and SOUL.md for how this folder is used.
